import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.util.List;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JLabel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;

public class ObjectSpy {

	private JFrame frame;
	private JTextField urlLink;
	private JButton btnOpen;
	private JTextField TypeTF;
	private JTextField IDTF;
	private JTextField NameTF;
	private JTextField ClassTF;
	private JTextField XPathTF;
	private JavascriptExecutor js;
	private WebDriver driver1;
	private JTextField XTF;
	private JTextField YTF;
	private JTextField CSSTF;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ObjectSpy window = new ObjectSpy();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public ObjectSpy() throws InterruptedException{
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		//frame.setState(Frame.NORMAL);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setSize(screenSize.width, screenSize.height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		urlLink = new JTextField();
		urlLink.setBounds(113, 180, 302, 43);
		frame.getContentPane().add(urlLink);
		urlLink.setColumns(10);
		
		String[] choices = { "Chrome", "Firefox" };
		JComboBox<String> comboBox = new JComboBox<>(choices);
		//JComboBox comboBox = new JComboBox(choices);
		comboBox.setBounds(474, 180, 109, 43);
		frame.getContentPane().add(comboBox);
		
		btnOpen = new JButton("Open");
		btnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String ch=comboBox.getSelectedItem().toString();
					String url=urlLink.getText().toString();
					
					String jscript = "document.onclick= function(event) {\r\n" + 
							"    if (event===undefined) event= window.event;                     \r\n" + 
							"    var target= 'target' in event? event.target : event.srcElement; \r\n" + 
							"	var root= document.compatMode==='CSS1Compat'? document.documentElement : document.body;\r\n" + 
							"    var XPath= getPathTo(target);\r\n" + 
							"	var txyz= getPageXYZ(target);\r\n" + 
							"    localStorage.setItem('XPath', XPath);\r\n" + 
							"}\r\n" + 
							"\r\n" + 
							"function getPathTo(element) {\r\n" + 
							"    if (element.id!=='')\r\n" + 
							"        return 'id(\"'+element.id+'\")';\r\n" + 
							"    if (element===document.body)\r\n" + 
							"        return element.tagName;\r\n" + 
							"\r\n" + 
							"    var ix= 0;\r\n" + 
							"    var siblings= element.parentNode.childNodes;\r\n" + 
							"    for (var i= 0; i<siblings.length; i++) {\r\n" + 
							"        var sibling= siblings[i];\r\n" + 
							"        if (sibling===element)\r\n" + 
							"            return getPathTo(element.parentNode)+'/'+element.tagName+'['+(ix+1)+']';\r\n" + 
							"        if (sibling.nodeType===1 && sibling.tagName===element.tagName)\r\n" + 
							"            ix++;\r\n" + 
							"    }\r\n" + 
							"}\r\n" + 
							"\r\n" + 
							"function getPageXYZ(element) {\r\n" + 
							"    var x= element.getAttribute(\"id\"); y= element.getAttribute(\"name\"); z= element.getAttribute(\"class\");\r\n" + 
							"    return [x, y, z];\r\n" + 
							"}";
					
					if(ch=="Chrome") {
						System.setProperty("webdriver.chrome.driver", "C:\\Users\\116907\\eclipse-workspace\\Project\\lib\\chromedriver.exe");
						driver1= new ChromeDriver();
						driver1.manage().window().maximize();
						//driver1.get("https://www.google.com/");
						driver1.get(url);
						js = (JavascriptExecutor)driver1;
						js.executeScript(jscript);

					}
					if(ch=="Firefox") {
						System.setProperty("webdriver.gecko.driver", "C:\\Users\\116907\\eclipse-workspace\\Project\\lib\\geckodriver.exe");
						WebDriver driver2 = new FirefoxDriver();
						driver2.manage().window().maximize();
						driver1.get(url);
						JavascriptExecutor js = (JavascriptExecutor)driver2;
						js.executeScript(jscript);
						
					}
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
			}
		});	
		
		btnOpen.setBounds(617, 177, 82, 46);
		frame.getContentPane().add(btnOpen);
		
		JLabel lblObjectSpy = new JLabel("Object Spy");
		lblObjectSpy.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblObjectSpy.setBounds(113, 29, 235, 54);
		frame.getContentPane().add(lblObjectSpy);
		
		JLabel URL = new JLabel("URL");
		URL.setFont(new Font("Tahoma", Font.PLAIN, 20));
		URL.setBounds(54, 180, 49, 43);
		frame.getContentPane().add(URL);
		
		JLabel Type = new JLabel("Type");
		Type.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Type.setBounds(54, 261, 44, 33);
		frame.getContentPane().add(Type);
		
		TypeTF = new JTextField();
		TypeTF.setBounds(160, 265, 188, 33);
		frame.getContentPane().add(TypeTF);
		TypeTF.setColumns(10);
		
		IDTF = new JTextField();
		IDTF.setColumns(10);
		IDTF.setBounds(160, 337, 188, 33);
		frame.getContentPane().add(IDTF);
		
		NameTF = new JTextField();
		NameTF.setColumns(10);
		NameTF.setBounds(160, 398, 188, 33);
		frame.getContentPane().add(NameTF);
		
		ClassTF = new JTextField();
		ClassTF.setColumns(10);
		ClassTF.setBounds(160, 461, 188, 33);
		frame.getContentPane().add(ClassTF);
		
		JLabel Name = new JLabel("Name");
		Name.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Name.setBounds(54, 394, 58, 33);
		frame.getContentPane().add(Name);
		
		JLabel Class = new JLabel("Class");
		Class.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Class.setBounds(54, 457, 49, 33);
		frame.getContentPane().add(Class);
		
		JLabel ID = new JLabel("ID");
		ID.setFont(new Font("Tahoma", Font.PLAIN, 20));
		ID.setBounds(54, 333, 44, 33);
		frame.getContentPane().add(ID);
		
		JButton Add = new JButton("Add");
		Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String keys[]=new String[8];
				keys[0]=TypeTF.getText();
				keys[1]=IDTF.getText();
				keys[2]=NameTF.getText();
				keys[3]=ClassTF.getText();
				keys[4]=XPathTF.getText();
				keys[5]=XTF.getText();
				keys[6]=YTF.getText();
				keys[7]=CSSTF.getText();
				
				try 
				{ 
					BufferedWriter out = new BufferedWriter(new FileWriter("XPath.txt", true));
					for(int i=0; i<8; ++i)
					{
						out.write(keys[i]); out.write(",");
					}
					out.newLine();
			        out.close(); 
			    } 
			    catch (IOException e1) 
				{ 
			        System.out.println("exception occoured" + e); 
			    } 
			}
		});
		Add.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Add.setBounds(54, 821, 133, 46);
		frame.getContentPane().add(Add);
		
		JButton Show = new JButton("Show");
		Show.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String js3= "var XPath=window.localStorage.getItem('XPath');\r\n" + 
						"return XPath;";
				String XPath = js.executeScript(js3).toString();
				WebElement we=driver1.findElement(By.xpath(XPath));
				TypeTF.setText(we.getAttribute("type"));
				IDTF.setText(we.getAttribute("id"));
				NameTF.setText(we.getAttribute("name"));
				ClassTF.setText(we.getAttribute("class"));
				XPathTF.setText(XPath);
				Point point = we.getLocation();
				XTF.setText(Integer.toString(point.getX()));
				YTF.setText(Integer.toString(point.getY()));
				
				String CSSXP = "//";
				if(we.getTagName()!=null) CSSXP=CSSXP.concat(we.getTagName());
				if(we.getTagName()==null) CSSXP=CSSXP.concat("*");
				CSSXP=CSSXP.concat("[");
				CSSXP=CSSXP.concat("@");
				
				//if(we.getAttribute("id")!=null) CSSXP=CSSXP.concat("id=" + "\'" + we.getAttribute("id") + "\'");
				
				List<WebElement> el = driver1.findElements(By.xpath("//*"));
				int count=0;
				
				String nameAttr=we.getAttribute("name");
				for (WebElement elem : el )
				{
					if(nameAttr.equals(elem.getAttribute("name")))
					{
						count++;
						if(count==2) break;
					}
				}
				if(count==1) CSSXP=CSSXP.concat("name=" + "\'" + we.getAttribute("name") + "\'");
				
				/*
				String classAttr=we.getAttribute("class");
				for (WebElement elem : el )
				{
					if(classAttr.equals(elem.getAttribute("class")))
					{
						count++;
						if(count==2) break;
					}
				}
				if(count==1) CSSXP=CSSXP.concat("class=" + "\'" + we.getAttribute("class") + "\'");
				*/
				
				CSSXP=CSSXP.concat("]");
				CSSTF.setText(CSSXP);
				
			}
		});
		Show.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Show.setBounds(474, 294, 109, 33);
		frame.getContentPane().add(Show);
		
		JLabel XPath = new JLabel("Xpath");
		XPath.setFont(new Font("Tahoma", Font.PLAIN, 20));
		XPath.setBounds(54, 528, 58, 33);
		frame.getContentPane().add(XPath);
		
		XPathTF = new JTextField();
		XPathTF.setColumns(10);
		XPathTF.setBounds(160, 532, 423, 33);
		frame.getContentPane().add(XPathTF);
		
		JButton TextFileShow = new JButton("TextFileShow");
		TextFileShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{ 
					BufferedReader reader = new BufferedReader(new FileReader("XPath.txt"));
					String line=reader.readLine();
					while(line!=null)
					{
						String XPath[] = line.split(",");
						System.out.println("Type: " + XPath[0]);
						System.out.println("ID: " + XPath[1]);
						System.out.println("Name: " + XPath[2]);
						System.out.println("Class: " + XPath[3]);
						System.out.println("XPath: " + XPath[4]);
						System.out.println("XCoordinate: " + XPath[5]);
						System.out.println("XCoordinate: " + XPath[6]);
						System.out.println("CSS: " + XPath[7]);
						System.out.println();
						line=reader.readLine();
					}
					reader.close();
			    } 
			    catch (IOException e1) 
				{ 
			        System.out.println("exception occoured" + e); 
			    }
			}
		});
		TextFileShow.setFont(new Font("Tahoma", Font.PLAIN, 20));
		TextFileShow.setBounds(564, 821, 188, 46);
		frame.getContentPane().add(TextFileShow);
		
		JLabel XCoordinate = new JLabel("XCoordinate");
		XCoordinate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		XCoordinate.setBounds(54, 609, 133, 33);
		frame.getContentPane().add(XCoordinate);
		
		XTF = new JTextField();
		XTF.setColumns(10);
		XTF.setBounds(206, 609, 188, 33);
		frame.getContentPane().add(XTF);
		
		JLabel YCoordinate = new JLabel("YCoordinate");
		YCoordinate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		YCoordinate.setBounds(54, 688, 133, 33);
		frame.getContentPane().add(YCoordinate);
		
		YTF = new JTextField();
		YTF.setColumns(10);
		YTF.setBounds(206, 688, 188, 33);
		frame.getContentPane().add(YTF);
		
		JButton Highlight = new JButton("Highlight");
		Highlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String XPath=XPathTF.getText();
				WebElement we=driver1.findElement(By.xpath(XPath));
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", we, "color: red; border: 2px solid red;");
			}
		});
		Highlight.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Highlight.setBounds(265, 821, 181, 46);
		frame.getContentPane().add(Highlight);
		
		JLabel CSS = new JLabel("CSS");
		CSS.setFont(new Font("Tahoma", Font.PLAIN, 20));
		CSS.setBounds(54, 752, 133, 33);
		frame.getContentPane().add(CSS);
		
		CSSTF = new JTextField();
		CSSTF.setColumns(10);
		CSSTF.setBounds(206, 752, 188, 33);
		frame.getContentPane().add(CSSTF);
		
	}
}